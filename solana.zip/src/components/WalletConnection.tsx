import React, { useEffect, useState } from "react";
import { useWallet } from "@solana/wallet-adapter-react";
import { WalletName } from "@solana/wallet-adapter-base";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../store";
import { setWalletConnection, disconnectWallet, setAuthToken, setWalletSigned } from "../store/authSlice";
import { authenticateWallet } from "../services/authService";
import styled from "styled-components";
import { PublicKey } from "@solana/web3.js";

// ✅ Node.js 환경이 아닐 때 Buffer 정의 (웹 환경 지원)
if (typeof window !== "undefined" && !globalThis.Buffer) {
  globalThis.Buffer = require("buffer").Buffer;
}

// ✅ 스타일 정의
const WalletButton = styled.button`
  background-color: ${(props) => props.theme.colors.primary};
  color: white;
  padding: 10px 15px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 16px;
  transition: background 0.3s;

  &:hover {
    background-color: ${(props) => props.theme.colors.primaryHover};
  }
`;

const WalletInfo = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
`;

const WalletAddress = styled.span`
  font-size: 14px;
  color: ${(props) => props.theme.colors.text};
`;

const ErrorMessage = styled.p`
  color: ${(props) => props.theme.colors.error};
  font-size: 14px;
`;

const LoadingMessage = styled.p`
  color: ${(props) => props.theme.colors.primary};
  font-size: 14px;
`;

interface AuthResponse {
  message?: string;
  token?: string;
  accessToken?: string;
  jwt?: string;
  error?: string;
}

// ✅ WalletConnection 컴포넌트
const WalletConnection: React.FC = () => {
  const wallet = useWallet();
  const dispatch = useDispatch();
  const { walletConnected, isSigned } = useSelector((state: RootState) => state.auth);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // ✅ 지갑 연결 감지
  useEffect(() => {
    if (wallet.connected && wallet.publicKey) {
      dispatch(
        setWalletConnection({
          connected: true,
          address: wallet.publicKey.toBase58(),
        })
      );
    } else {
      dispatch(disconnectWallet());
    }
  }, [wallet.connected, wallet.publicKey, dispatch]);

  // ✅ 지갑 연결 핸들러
  const handleConnect = async () => {
    try {
      if (wallet.wallet) {
        await wallet.connect();
      } else {
        wallet.select("phantom" as WalletName<string>);
      }
      setErrorMessage(null);
    } catch (error) {
      console.error("❌ 지갑 연결 실패:", error);
      setErrorMessage("지갑 연결에 실패했습니다. 다시 시도해주세요.");
    }
  };

  // ✅ 지갑 연결 해제 핸들러
  const handleDisconnect = async () => {
    try {
      await wallet.disconnect();
      dispatch(disconnectWallet());
      setErrorMessage(null);
    } catch (error) {
      console.error("❌ 지갑 연결 해제 실패:", error);
      setErrorMessage("지갑 연결 해제 중 오류가 발생했습니다.");
    }
  };

  // ✅ 지갑 인증 핸들러
  const handleAuthenticate = async () => {
    try {
      if (!wallet.connected || !wallet.publicKey) {
        console.error("🚨 지갑이 연결되지 않음! 연결 시도...");
        await handleConnect();
        return;
      }
  
      setLoading(true);
  
      // ✅ PublicKey 변환 처리
      let publicKey: string;
      try {
        publicKey = new PublicKey(wallet.publicKey.toString()).toBase58();
      } catch (error) {
        throw new Error("❌ PublicKey 변환 실패: 올바르지 않은 형식의 지갑 주소");
      }
  
      // ✅ 메시지 서명 가능 여부 확인
      if (!wallet.signMessage) {
        throw new Error("❌ 현재 사용 중인 지갑에서는 메시지 서명이 지원되지 않습니다. Phantom, Solflare 같은 지갑을 사용하세요.");
      }
  
      // ✅ 메시지 서명 (Solana 인증)
      const message = `Sign this message to authenticate: ${new Date().toISOString()}`;
      const encodedMessage = new TextEncoder().encode(message);
      const signedMessage = await wallet.signMessage(encodedMessage);
  
      // ✅ 서명 데이터 변환
      const signature = Buffer.from(signedMessage).toString("base64");
  
      // ✅ 백엔드 API 호출
      const response = (await authenticateWallet({ publicKey, message, signature })) as AuthResponse;
      console.log("🔹 인증 응답:", response);
  
      if (response?.token) {
        dispatch(setAuthToken(response.token));
        dispatch(setWalletSigned(true));
        alert("✅ 인증 성공! Ex2Earn을 이용할 수 있습니다.");
      } else {
        console.error("❌ 잘못된 응답 형식:", response);
        setErrorMessage(response.error || "❌ 인증 실패: 서버 응답이 올바르지 않습니다.");
      }
    } catch (error) {
      console.error("❌ 인증 오류:", error);
      setErrorMessage(`❌ 인증에 실패했습니다: ${error instanceof Error ? error.message : "알 수 없는 오류 발생"}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      {!walletConnected ? (
        <WalletButton onClick={handleConnect}>지갑 연결</WalletButton>
      ) : (
        <WalletInfo>
          {/* ✅ 지갑이 연결되지 않았을 경우 '지갑 연결 필요' 메시지 출력 */}
          {wallet.publicKey ? (
            <WalletAddress>
              {wallet.publicKey.toBase58().slice(0, 4)}...
              {wallet.publicKey.toBase58().slice(-4)}
            </WalletAddress>
          ) : (
            <WalletAddress>🔹 지갑 연결 필요</WalletAddress>
          )}

          {!isSigned ? (
            <WalletButton onClick={handleAuthenticate}>메시지 서명 후 인증</WalletButton>
          ) : (
            <WalletButton onClick={handleDisconnect}>연결 해제</WalletButton>
          )}
        </WalletInfo>
      )}

      {loading && <LoadingMessage>⏳ 인증 진행 중...</LoadingMessage>}
      {errorMessage && <ErrorMessage>{errorMessage}</ErrorMessage>}
    </div>
  );
};

export default WalletConnection;
