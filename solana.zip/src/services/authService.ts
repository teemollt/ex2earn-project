import { PublicKey } from "@solana/web3.js";
import { apiCall } from "./apiService"; // 기존 API 요청 함수 사용

// ✅ Node.js 환경이 아닐 때 Buffer 정의 (웹 환경 지원)
if (typeof window !== "undefined" && !globalThis.Buffer) {
  globalThis.Buffer = require("buffer").Buffer;
}

// ✅ 지갑 인증 함수
export const authenticateWallet = async (wallet: any) => {
  if (!wallet || !wallet.publicKey) {
    throw new Error("❌ 지갑이 연결되지 않았습니다.");
  }

  let publicKey: string;
  try {
    publicKey = new PublicKey(wallet.publicKey.toString()).toBase58();
  } catch (error) {
    throw new Error("❌ PublicKey 변환 실패: 올바르지 않은 형식의 지갑 주소");
  }

  const message = `Sign this message to authenticate: ${new Date().toISOString()}`;
  const encodedMessage = new TextEncoder().encode(message);

  try {
    // ✅ 메시지 서명 가능 여부 확인
    if (!wallet.signMessage) {
      throw new Error("❌ 현재 사용 중인 지갑에서는 메시지 서명이 지원되지 않습니다.");
    }

    const signedMessage = await wallet.signMessage(encodedMessage);
    const signature = Buffer.from(signedMessage).toString("base64");

    // ✅ API 호출 시 엔드포인트 수정 (/auth/wallet → /wallet-auth)
    return await apiCall("/wallet-auth", "POST", { publicKey, message, signature });
  } catch (error) {
    console.error("❌ 메시지 서명 실패:", error);
    throw error;
  }
};
